# 資料處理

首先執行 `dataprocess.py` 將資料先轉換到 84 維，並存在 `cooked_train` 裡面

# 執行模擬

`Q10.py`、`Q11.py` 跟 `Q12.py` 分別是三題的執行檔。

`Q11.py` 跟 `Q12.py` 會將結果先存起來，之後再用 `Myplot.py` 畫出來。